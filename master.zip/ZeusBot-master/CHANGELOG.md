# Changelog

`+` = Added, `-` = Removed, `~` = Changed

## Version 2.x

### v2.2
[29.12.2017]  
`~` Update: update.py [cf47dae](https://github.com/OlympicCode/vHackXTBot-Python/commit/cf47daea4af872633517a372c7ff19c9e7fff450)  
`~` Update: main.py [293315](https://github.com/OlympicCode/vHackXTBot-Python/commit/29333159f2328d83f30f4c14a909d8d6baaad5cf)

### v2.1
[29.12.2017]  
`~` Bugfix: Added output of level for updating

### v2.0
[29.12.2017]  
`~` Rewrote the Messages to be better understood