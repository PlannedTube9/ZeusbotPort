# Contributers of ZeusBot
+ [vBlackOut](https://github.com/vBlackOut) 
+ [AtjonTV](https://github.com/AtjonTV) &lt;admin.atjontv@atvg-studios.at&gt; (http://atvg-studios.at)

# Contributers of vHackXTBot
+ [vBlackOut](https://github.com/vBlackOut) 
+ [JasonKhew96](https://github.com/JasonKhew96)
+ [checkium](https://github.com/checkium)
+ [HybridFox](https://github.com/HybridFox)
+ [wookienz](https://github.com/)wookienz

# Thanks to
+ [flatt3rn](https://github.com/flatt3rn)
+ [WookieNZ](https://github.com/WookieNZ)
+ [JasonKhew96](https://github.com/JasonKhew96)