i removed but the script python run for multi platform
